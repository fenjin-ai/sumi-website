Original LeftBlank examples / 留白原创示例
Open a .typ file in LeftBlank. The diagram example uses @preview/cetz:0.5.2.
Presentation examples export to PDF, not PPTX.
https://leftblank.app
